This demo font is for PERSONAL USE ONLY! 

But any donation is very appreciated.
►►► Paypal account for donation : paypal.me/goicha

GET Unique Fonts with a value of more than $300 for just $44 
►►► http://goicha.org/downloads/goichas-font-bundle/

Thank You